// Define global variables used in the application
declare global {
  namespace NodeJS {
    interface Global {
      adminEmail: string;
    }
  }
}

export {};