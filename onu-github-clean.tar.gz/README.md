# ONU Parts Tracker

Production-ready parts management system with automated email receipts.

## Quick Deploy to Vercel

1. Connect this GitHub repo to Vercel
2. Set environment variables:
   - DATABASE_URL: your Neon connection string  
   - GMAIL_USER: onupartsdelivery@gmail.com
   - GMAIL_PASSWORD: your app password
3. Deploy!

## Features
- Automated email receipts
- Real-time inventory tracking  
- Staff management
- Cost center integration
- Barcode scanning
- Mobile-optimized interface

Database already migrated to Neon with 1,526+ parts.
